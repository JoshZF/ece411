#include <stdbool.h>

void swap(volatile int* xp, volatile int* yp) {
    volatile int tmp = *xp;
    *xp = *yp;
    *yp = tmp;
}

void
bubbleSort (volatile int arr[], int n) {
    int i, j;
    bool swapped;
    for (i = 0; i < n - 1; i++) {
        swapped = false;
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(&arr[i], &arr[j + 1]);
                swapped = true;
            }
        }
        if (swapped == false) break;
    }
}

int main() {
    volatile int a[] = {64, 32, 10, 100, 18, 2, 4, 65};
    int n = sizeof(a) / sizeof(a[0]);

    bubbleSort(a, n);
}