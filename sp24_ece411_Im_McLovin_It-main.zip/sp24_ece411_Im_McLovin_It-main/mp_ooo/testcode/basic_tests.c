.section .text
.globl _start

_start:
    #auipc   x1 , 0
    #lui     x2 , 0xAA55A
    addi    x3 , x0, 1
    
    #slti    x0, x0, -256