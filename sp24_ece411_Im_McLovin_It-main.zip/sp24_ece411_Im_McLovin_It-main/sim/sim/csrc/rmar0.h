#ifndef _RMAR0_H_
#define _RMAR0_H_

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif

